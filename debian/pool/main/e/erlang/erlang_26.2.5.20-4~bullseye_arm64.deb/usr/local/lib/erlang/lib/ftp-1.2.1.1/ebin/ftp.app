{application, ftp,
 [{description, "FTP client"},
  {vsn, "1.2.1.1"},
  {registered, []},
  {mod, { ftp_app, []}},
  {applications,
   [kernel,
    stdlib
   ]},
  {env,[]},
  {modules, [
             ftp,
             ftp_app,
             ftp_progress,
             ftp_internal,
             ftp_response,
             ftp_sup
            ]},
  {runtime_dependencies, ["erts-7.0","stdlib-3.5","kernel-6.0","ssl-10.2","runtime_tools-1.15.1"]}
 ]}.
