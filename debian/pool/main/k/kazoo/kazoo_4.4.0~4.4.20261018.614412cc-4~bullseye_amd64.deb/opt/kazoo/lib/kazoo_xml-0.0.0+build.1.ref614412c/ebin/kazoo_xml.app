{application,kazoo_xml,
             [{description,"Helpers for manipulating XML records"},
              {vsn,"0.0.0+build.1.ref614412c"},
              {modules,[kz_xml]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo,lager]}]}.
