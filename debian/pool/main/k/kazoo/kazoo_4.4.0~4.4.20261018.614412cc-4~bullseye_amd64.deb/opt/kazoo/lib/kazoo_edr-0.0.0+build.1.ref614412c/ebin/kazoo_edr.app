{application,kazoo_edr,
             [{description,"EDR core component"},
              {vsn,"0.0.0+build.1.ref614412c"},
              {modules,[edr_bindings,kz_edr]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo_bindings]}]}.
