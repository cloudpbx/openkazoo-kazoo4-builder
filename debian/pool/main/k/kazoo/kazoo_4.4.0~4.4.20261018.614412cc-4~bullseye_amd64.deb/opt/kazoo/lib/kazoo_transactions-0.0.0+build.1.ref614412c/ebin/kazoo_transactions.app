{application,kazoo_transactions,
             [{description,"Abstract transactions to be sent to bookkeepers for processing"},
              {vsn,"0.0.0+build.1.ref614412c"},
              {modules,[kz_transaction,kz_transactions]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo,kazoo_data,kazoo_config,
                             kazoo_modb,lager]}]}.
