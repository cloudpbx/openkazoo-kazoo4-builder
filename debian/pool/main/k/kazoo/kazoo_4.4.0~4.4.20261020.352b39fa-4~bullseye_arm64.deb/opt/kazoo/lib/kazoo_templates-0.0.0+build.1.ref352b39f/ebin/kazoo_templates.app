{application,kazoo_templates,
             [{description,"Blowing pigment over documents like never before"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[kz_pdf,kz_template]},
              {registered,[]},
              {applications,[kernel,stdlib,crypto,kazoo,erlydtl,lager]}]}.
