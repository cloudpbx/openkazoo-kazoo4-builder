{application,webseq,
             [{description,"Web Sequence Diagram Builder"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[webseq,webseq_diagram_srv]},
              {registered,[]},
              {applications,[kernel,stdlib,crypto,kazoo,kazoo_data,gproc,
                             lager]}]}.
