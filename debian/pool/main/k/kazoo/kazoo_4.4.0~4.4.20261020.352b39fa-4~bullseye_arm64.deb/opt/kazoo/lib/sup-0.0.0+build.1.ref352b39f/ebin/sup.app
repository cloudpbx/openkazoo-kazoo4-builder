{application,sup,
             [{description,"Accept RPC requests & push them into a running Kazoo VM"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[sup]},
              {registered,[]},
              {applications,[kernel,stdlib,getopt,kazoo,kazoo_stdlib,
                             kazoo_config,zucchini,lager]},
              {env,[]}]}.
