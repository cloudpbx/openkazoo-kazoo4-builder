{application,kazoo_etsmgr,
             [{description,"Kazoo ETS Manager - Protect the ETS"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[kazoo_etsmgr_srv]},
              {registered,[]},
              {applications,[kernel,stdlib,crypto,kazoo,lager]}]}.
