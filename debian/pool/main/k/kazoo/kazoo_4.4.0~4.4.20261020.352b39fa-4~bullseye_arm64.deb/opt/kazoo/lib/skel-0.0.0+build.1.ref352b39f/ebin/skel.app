{application,skel,
             [{applications,[kazoo,kazoo_amqp,kazoo_apps,kazoo_call,
                             kazoo_stdlib,kernel,lager,stdlib]},
              {description,"Skel - A skeleton application useful for quickly creating services"},
              {env,[{is_kazoo_app,true}]},
              {mod,{skel_app,[]}},
              {modules,[skel_app,skel_handlers,skel_listener,skel_sup]},
              {registered,[skel_cache,skel_sup]},
              {vsn,"0.0.0+build.1.ref352b39f"}]}.
