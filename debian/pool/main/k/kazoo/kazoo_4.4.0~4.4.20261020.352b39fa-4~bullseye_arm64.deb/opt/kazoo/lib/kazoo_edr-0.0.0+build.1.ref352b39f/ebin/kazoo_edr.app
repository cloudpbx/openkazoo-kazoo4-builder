{application,kazoo_edr,
             [{description,"EDR core component"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[edr_bindings,kz_edr]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo_bindings]}]}.
