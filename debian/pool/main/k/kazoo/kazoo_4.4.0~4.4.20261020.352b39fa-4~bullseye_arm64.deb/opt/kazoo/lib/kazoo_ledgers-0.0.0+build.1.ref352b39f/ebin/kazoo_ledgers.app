{application,kazoo_ledgers,
             [{description,"Kazoo ledgers management"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[kazoo_ledgers_maintenance,kz_ledger,kz_ledgers]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo,kazoo_modb]}]}.
