{application,kazoo,
             [{applications,[inets,kazoo_stdlib,kernel,lager,stdlib]},
              {description,"Kazoo Helpers"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[kazoo_maintenance,kz_base64url,kz_doc,kz_mime,kz_util,
                        perf]},
              {registered,[]}]}.
