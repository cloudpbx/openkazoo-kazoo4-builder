{application,kazoo_tasks,
             [{description,"Kazoo Tasks - Application library for Tasks"},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[kz_tasks]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo,kazoo_csv]}]}.
