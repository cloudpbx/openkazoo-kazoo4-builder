{application,kazoo_csv,
             [{description,"Kazoo CSV - Application library for handling CSV files (RFC4180)."},
              {vsn,"0.0.0+build.1.ref352b39f"},
              {modules,[kz_csv]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo]}]}.
