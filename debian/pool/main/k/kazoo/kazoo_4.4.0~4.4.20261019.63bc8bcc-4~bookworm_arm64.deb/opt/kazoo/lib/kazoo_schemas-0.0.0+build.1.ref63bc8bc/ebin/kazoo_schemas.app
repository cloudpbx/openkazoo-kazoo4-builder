{application,kazoo_schemas,
             [{description,"JSON Schema handling"},
              {vsn,"0.0.0+build.1.ref63bc8bc"},
              {modules,[kazoo_schemas_maintenance,kz_json_schema,
                        kz_json_schema_extensions]},
              {registered,[]},
              {applications,[kernel,stdlib,lager,kazoo_stdlib,jesse]}]}.
