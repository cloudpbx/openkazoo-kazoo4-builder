{application,martini,
             [{applications,[kernel,lager,stdlib]},
              {description,"martini - STIR/SHAKEN support"},
              {env,[{is_kazoo_app,true}]},
              {mod,{martini_app,[]}},
              {modules,[martini,martini_error]},
              {registered,[]},
              {vsn,"1.0.3"}]}.
