{application,kazoo_sip,
             [{description,"Kazoo SIP Utilities"},
              {vsn,"0.0.0+build.1.ref63bc8bc"},
              {modules,[kzsip_diversion,kzsip_parse,kzsip_parse_tokens,
                        kzsip_parse_uri,kzsip_unparse,kzsip_uri]},
              {registered,[]},
              {applications,[kernel,stdlib,kazoo,kazoo_number_manager,
                             lager]}]}.
