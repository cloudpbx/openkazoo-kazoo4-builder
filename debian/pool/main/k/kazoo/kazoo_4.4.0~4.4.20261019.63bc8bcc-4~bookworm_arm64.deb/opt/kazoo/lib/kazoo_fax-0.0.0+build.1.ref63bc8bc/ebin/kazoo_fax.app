{application,kazoo_fax,
             [{description,"Kazoo fax provides core helper functions for handling fax attachments"},
              {vsn,"0.0.0+build.1.ref63bc8bc"},
              {modules,[kz_fax_attachment]},
              {registered,[]},
              {applications,[kernel,stdlib,crypto,kazoo,kazoo_convert,
                             kazoo_data,kazoo_config,lager]}]}.
