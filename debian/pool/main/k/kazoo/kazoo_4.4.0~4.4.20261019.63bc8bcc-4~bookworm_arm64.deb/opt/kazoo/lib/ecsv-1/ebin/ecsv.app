{application,ecsv,
             [{description,"Erlang CSV parsing and generation library"},
              {vsn,"1"},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {env,[]},
              {modules,[ecsv,ecsv_parser,ecsv_reader]}]}.
