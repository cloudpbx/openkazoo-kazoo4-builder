{application,inet_cidr,
             [{description,"CIDR library for Erlang"},
              {vsn,"1.2.1"},
              {modules,[inet_cidr]},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {licenses,["MIT"]},
              {links,[{"Github","https://github.com/benoitc/inet_cidr"}]},
              {pkg_name,"erl_cidr"}]}.
