{application,kazoo_perf,
             [{description,"Kazoo Peformance testing"},
              {vsn,"0.0.0+build.1.ref63bc8bc"},
              {modules,[kazoo_perf_maintenance,kz_dbg,kz_tracers]},
              {registered,[]},
              {applications,[kernel,stdlib,crypto,inets,kazoo,kazoo_amqp,
                             kazoo_data,lager]}]}.
